TrustBeat Signature Preservation package (trustbeat-signature-preservation-package-v1)

One preserved signed file. The file itself is not here: it never left your machine. Keep it next to
this package. Contents:

  manifest.json                 Record id, preservation profile and period, the PEO's digests, and the
                                SHA-256 of every other file in this package.
  peo.json                      The Preservation Evidence Object, byte for byte as preserved: canonical
                                JSON (RFC 8785). Its SHA-256 is what the evidence record covers.
  signatures/<n>.p7s | .xml     Each signature (CMS for PAdES / CAdES / ASiC CAdES, XML for XAdES), as
                                taken from your file — or the derived copy the PEO describes (`derived`).
  signatures/<n>-asic-manifest.xml  The ASiCManifest an ASiC-E CAdES signature signs.
  timestamps/<n>.tst            PDF document timestamps and ASiC container / archive timestamps.
  validation-data/              Certificates, OCSP responses and CRLs collected at preservation time.
  evidence-record.ers           RFC 4998 evidence record over the PEO's SHA-256 (DER), with its
                                time-stamp renewals; missing while the first one is being made.
  trusted-lists/<CC>-<seq>.xml  The signed EU trusted lists in force at preservation time.

Verifying, with the original file. In one command, offline (steps 1-3 and 7, and the package itself):

  trustbeat-signature verify <your file> --package <this zip>

TrustBeat's POST /v1/signature-preservation/{id}/verify adds steps 4-6 (EU DSS again, offline, at
preservation time, on the data in this package) and a PDF report. Step by step, with standard tools:

  1. File: compute the SHA-256 / SHA-512 / SHA3-512 of your file and compare with peo.json
     "container"."digests" (and "data_objects" for detached data or ASiC content).
  2. Binding: rebuild what each signature signs from your file — the PDF /ByteRange, the data file, the
     XML references after their transforms — and compare its digest with the signature's "binding"
     entries. `trustbeat-signature extract <file>` prints the same digests.
  3. Signature: verify each signature in signatures/ over its signed attributes / SignedInfo with the
     signer certificate (no file and no network needed; any EU DSS validator, OpenSSL for CMS).
  4. Chain and revocation: validate the signer certificate with validation-data/ — the OCSP and CRLs from
     preservation time, not fresh ones.
  5. Signature timestamps: the signature existed no later than their time, while the certificate was valid.
  6. Qualification: check the signer's issuer in trusted-lists/ as of the signing time.
  7. Evidence record: hash peo.json with SHA-256 and verify evidence-record.ers over it (EU DSS, or BSI
     ERVerifyTool). This proves the PEO — signatures, bindings and validation data — existed unchanged
     since preservation.
  8. Report: peo.json "signatures"[*]."dss" records what EU DSS reported at preservation time;
     "checked_by" says who established each fact.

What it proves: a signature, valid or not as recorded, existed over content with the digests in the
PEO no later than the evidence record's first time-stamp; with your file, that the content is your file.
